jQuery(function($) {
    $('.burger__wrapper').on('click', function(){
        //$('.sidebar__mobile').toggle();
        $('.burger__menu').addClass('is-animate');
        $('.sidebar__mobile').addClass('is-open');
        $('.overlay').toggle();
        $('body').addClass('no-scroll');
        })
    
    $('.overlay').on('click', function(){
        $('.overlay').toggle();
        $('.burger__menu').removeClass('is-animate');
        $('.sidebar__mobile').removeClass('is-open');
        //$('.sidebar__mobile').toggle();
        $('body').removeClass('no-scroll');        
    })
)}